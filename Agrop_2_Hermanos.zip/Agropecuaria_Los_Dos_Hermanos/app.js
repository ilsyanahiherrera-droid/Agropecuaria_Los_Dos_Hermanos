/* ==========================================================
   AGROPECUARIA EL BUEN CAMPO - app.js
   JavaScript puro: carrusel, carrito y formularios.
   No necesita Internet ni librerías externas.
   ========================================================== */

const CLAVE_CARRITO = "buen_campo_carrito";

/* -------------------- CARRUSEL -------------------- */
const diapositivas = [
    {
        titulo: "Bienvenidos a <span>Agropecuaria Los Dos Hermanos</span>",
        texto: "Productos agropecuarios confiables para apoyar el trabajo y el crecimiento de tu producción.",
        fondo: "img/campo.jpg",
        etiqueta: "Calidad para el campo"
    },
    {
        titulo: "Cuidamos la salud de <span>tu ganado</span>",
        texto: "Encuentra vitaminas, minerales y productos veterinarios para distintas especies.",
        fondo: "img/ganado.jpg",
        etiqueta: "Atención especializada"
    },
    {
        titulo: "Soluciones para una <span>mejor cosecha</span>",
        texto: "Te acompañamos con productos seleccionados y asesoría para tomar mejores decisiones.",
        fondo: "img/tractor.jpg",
        etiqueta: "Tu aliado agropecuario"
    }
];

let diapositivaActual = 0;
let temporizadorCarrusel;

function prepararCarrusel() {
    const hero = document.getElementById("heroSlider");
    if (!hero) return;

    mostrarDiapositiva(0);
    temporizadorCarrusel = setInterval(() => {
        siguienteDiapositiva();
    }, 5000);

    hero.addEventListener("mouseenter", () => clearInterval(temporizadorCarrusel));
    hero.addEventListener("mouseleave", () => {
        clearInterval(temporizadorCarrusel);
        temporizadorCarrusel = setInterval(siguienteDiapositiva, 5000);
    });
}

function mostrarDiapositiva(indice) {
    const hero = document.getElementById("heroSlider");
    const titulo = document.getElementById("heroTitle");
    const texto = document.getElementById("heroText");
    const etiqueta = document.getElementById("heroLabel");
    const puntos = document.querySelectorAll(".dot");

    if (!hero || !titulo || !texto) return;

    diapositivaActual = (indice + diapositivas.length) % diapositivas.length;
    const diapositiva = diapositivas[diapositivaActual];

    hero.style.backgroundImage = `linear-gradient(90deg, rgba(15, 37, 21, 0.86), rgba(15, 37, 21, 0.28)), url("${diapositiva.fondo}")`;
    titulo.innerHTML = diapositiva.titulo;
    texto.textContent = diapositiva.texto;
    if (etiqueta) etiqueta.textContent = diapositiva.etiqueta;

    puntos.forEach((punto, posicion) => {
        punto.classList.toggle("active", posicion === diapositivaActual);
        punto.setAttribute("aria-current", posicion === diapositivaActual ? "true" : "false");
    });
}

function siguienteDiapositiva() {
    mostrarDiapositiva(diapositivaActual + 1);
}

function anteriorDiapositiva() {
    mostrarDiapositiva(diapositivaActual - 1);
}

function seleccionarDiapositiva(indice) {
    mostrarDiapositiva(indice);
}

/* -------------------- CARRITO -------------------- */
function obtenerCarrito() {
    try {
        return JSON.parse(localStorage.getItem(CLAVE_CARRITO)) || [];
    } catch (error) {
        return [];
    }
}

function guardarCarrito(carrito) {
    localStorage.setItem(CLAVE_CARRITO, JSON.stringify(carrito));
}

function actualizarContador() {
    const carrito = obtenerCarrito();
    const cantidad = carrito.reduce((total, producto) => total + producto.cantidad, 0);
    document.querySelectorAll(".cart-count").forEach((contador) => {
        contador.textContent = cantidad;
    });
}

function agregarAlCarrito(id, nombre, precio, imagen, categoria) {
    const carrito = obtenerCarrito();
    const productoExistente = carrito.find((producto) => producto.id === id);

    if (productoExistente) {
        productoExistente.cantidad += 1;
    } else {
        carrito.push({
            id: id,
            nombre: nombre,
            precio: Number(precio),
            imagen: imagen,
            categoria: categoria,
            cantidad: 1
        });
    }

    guardarCarrito(carrito);
    actualizarContador();
    mostrarMensaje(`"${nombre}" se agregó al carrito.`);
}

function cambiarCantidad(indice, cambio) {
    const carrito = obtenerCarrito();
    if (!carrito[indice]) return;

    carrito[indice].cantidad += cambio;
    if (carrito[indice].cantidad <= 0) {
        carrito.splice(indice, 1);
    }

    guardarCarrito(carrito);
    actualizarContador();
    mostrarCarrito();
}

function eliminarDelCarrito(indice) {
    const carrito = obtenerCarrito();
    if (!carrito[indice]) return;

    carrito.splice(indice, 1);
    guardarCarrito(carrito);
    actualizarContador();
    mostrarCarrito();
}

function vaciarCarrito() {
    const carrito = obtenerCarrito();
    if (carrito.length === 0) {
        mostrarMensaje("El carrito ya está vacío.");
        return;
    }

    localStorage.removeItem(CLAVE_CARRITO);
    actualizarContador();
    mostrarCarrito();
    mostrarMensaje("El carrito se vació correctamente.");
}

function comprarProductos() {
    const carrito = obtenerCarrito();
    if (carrito.length === 0) {
        mostrarMensaje("Primero agrega un producto al carrito.");
        return;
    }

    localStorage.removeItem(CLAVE_CARRITO);
    actualizarContador();
    mostrarCarrito();
    mostrarMensaje("Compra simulada realizada correctamente. ¡Gracias por elegir Agropecuaria Los Dos Hermanos!");
}

function mostrarCarrito() {
    const cuerpoTabla = document.getElementById("cartTableBody");
    const totalElemento = document.getElementById("cartTotal");
    if (!cuerpoTabla || !totalElemento) return;

    const carrito = obtenerCarrito();
    cuerpoTabla.innerHTML = "";

    if (carrito.length === 0) {
        cuerpoTabla.innerHTML = `
            <tr>
                <td colspan="6" class="empty-cart">
                    Tu carrito está vacío. <a href="productos.html" style="color: var(--verde); font-weight: 700;">Ver productos</a>
                </td>
            </tr>
        `;
        totalElemento.textContent = "$0.00";
        return;
    }

    let total = 0;

    carrito.forEach((producto, indice) => {
        const subtotal = producto.precio * producto.cantidad;
        total += subtotal;

        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>
                <div style="display:flex; align-items:center; gap:10px; min-width:210px;">
                    <img src="${producto.imagen}" alt="${producto.nombre}" style="width:58px;height:48px;object-fit:cover;border-radius:7px;">
                    <div><strong>${producto.nombre}</strong><br><small>${producto.categoria}</small></div>
                </div>
            </td>
            <td>$${producto.precio.toFixed(2)}</td>
            <td>
                <div style="display:flex; align-items:center; gap:8px;">
                    <button class="btn-buy" style="padding:4px 9px;" onclick="cambiarCantidad(${indice}, -1)" aria-label="Disminuir cantidad">−</button>
                    <strong>${producto.cantidad}</strong>
                    <button class="btn-buy" style="padding:4px 9px;" onclick="cambiarCantidad(${indice}, 1)" aria-label="Aumentar cantidad">+</button>
                </div>
            </td>
            <td>$${subtotal.toFixed(2)}</td>
            <td><button class="btn-danger" onclick="eliminarDelCarrito(${indice})">Eliminar</button></td>
        `;
        cuerpoTabla.appendChild(fila);
    });

    totalElemento.textContent = `$${total.toFixed(2)}`;
}

/* -------------------- MENSAJES Y FORMULARIO -------------------- */
function mostrarMensaje(texto) {
    const mensaje = document.getElementById("statusMessage");
    if (mensaje) {
        mensaje.textContent = texto;
        mensaje.classList.add("show");
        clearTimeout(window.temporizadorMensaje);
        window.temporizadorMensaje = setTimeout(() => {
            mensaje.classList.remove("show");
        }, 3000);
        return;
    }

    const avisoAnterior = document.querySelector(".site-notice");
    if (avisoAnterior) avisoAnterior.remove();

    const aviso = document.createElement("div");
    aviso.className = "site-notice";
    aviso.setAttribute("role", "status");
    aviso.textContent = texto;
    document.body.appendChild(aviso);
    window.temporizadorAviso = setTimeout(() => aviso.remove(), 3000);
}

function prepararFormularioContacto() {
    const formulario = document.getElementById("contactForm");
    if (!formulario) return;

    formulario.addEventListener("submit", (evento) => {
        evento.preventDefault();
        mostrarMensaje("Mensaje enviado correctamente. Te responderemos pronto.");
        formulario.reset();
    });
}

/* Las funciones se conectan con los botones onclick del HTML. */
window.siguienteDiapositiva = siguienteDiapositiva;
window.anteriorDiapositiva = anteriorDiapositiva;
window.seleccionarDiapositiva = seleccionarDiapositiva;
window.agregarAlCarrito = agregarAlCarrito;
window.cambiarCantidad = cambiarCantidad;
window.eliminarDelCarrito = eliminarDelCarrito;
window.vaciarCarrito = vaciarCarrito;
window.comprarProductos = comprarProductos;

window.addEventListener("DOMContentLoaded", () => {
    prepararCarrusel();
    actualizarContador();
    mostrarCarrito();
    prepararFormularioContacto();
});
